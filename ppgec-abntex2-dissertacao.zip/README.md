# PPGEC-abnTeX2

Customização do [abnTeX2](http://www.abntex.net.br/) para dissertações de mestrado do PPGEC - UPE. 

Para utilizar o modelo é necessário a instalação do LaTeX e do pacocte abnTeX2. Mais informações sobre a instalação em: [Guia para instalação do LaTeX e abnTeX2](https://github.com/abntex/abntex2/wiki/Instalacao).

[Exemplo de documento gerado com o modelo.](https://github.com/victormelo/ppgec-abntex2/blob/master/ppgec-abntex2-modelo.pdf)
